/* Homework 2 Kyler Kershaw
 * 09/09/2019
 * Create a program that uses a switch to call different functions
 * that demonstrate how a loop works.
 */

/* Menu displays 1, 2, 3, 4
 * Get user input and use that to select switch of the following:
 * 
 * Selection 1, While loop
 * Selection 2, Do while loop
 * Selection 3, For loop
 * Selection 4, Exit the program
*/
package hw_02_kershawkyler;

/**
 *
 * @author kyler
 */
public class HW_02_KershawKyler {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
