/* Homework 2 Kyler Kershaw
 * 09/09/2019
 * Create a program that uses a switch to call different functions
 * that demonstrate how a loop works.
 */

/* Menu displays 1, 2, 3, 4
 * Get user input and use that to select switch of the following:
 * 
 * Selection 1, While loop
 * Selection 2, Do while loop
 * Selection 3, For loop
 * Selection 4, Exit the program
*/
package hw_02_kershawkyler;
import javax.swing.JOptionPane;
import java.util.Scanner;

public class HW_02_KershawKyler {
    
    public static void menu(){
        // Display the menu to the user.
        format();
        System.out.print("\nThis program will run through a series of different"
                + "loops. \nPlease select which loop you'd like to use: \n");
        System.out.println("1. While loop");
        System.out.println("2. Do while loop");
        System.out.println("3. For loop");
        format();
    }
    
    public static void format(){
        System.out.println("\n===================================================="
                + "\n====================================================");
    }
    
    public static void switchFunction(Integer menuSelection){
        // This function takes an integer and uses it to select
        // which function the user wants to run.
        
        switch(menuSelection){
            case 1: whileLoop();
                    break;
            
            case 2: doWhileLoop();
                    break;
            
            case 3: forLoop();
                    break;
        }
    }
    
    public static boolean goAgain(){
        // This function will as the user if they want to use the program again.
        Integer userGoAgainInput = 0;
        Boolean goAgain;
        
        format();
        
        // Ask the user if they want to repeat and get proper input
        while (userGoAgainInput <=0 || userGoAgainInput >2){
            System.out.println("Would you like to repeat the program? ");
            System.out.println("1. Yes \n2. No");
            userGoAgainInput = getNumberFromUser();
        }
        // Assign their input to the proper selection.
        if (userGoAgainInput == 1){
            goAgain = true;
        }
        else{
            goAgain = false;
        }
        // Return the bool selection.
        return goAgain;
    }
    
    public static Integer getNumberFromUser(){
        // This function will prompt the user for input and convert it 
        // to an Integer. It will also validate the input to make sure it is a
        // number.
        
        // Variables
        Integer userSelection;
        Scanner keyboard = new Scanner(System.in);
        
        while (true){
            try{
                System.out.println("Please enter a number: ");
                userSelection = Integer.parseInt(keyboard.nextLine());
                break;
            }
            catch(NumberFormatException e){
                System.out.print("Invalid input. \n");
            }
        }
        
        return userSelection;
        
    }
    
    public static void whileLoop(){
        // The while loop demo goes here
        Integer counter = 0;
        System.out.print("While Loop:\n");
        System.out.print("The while loop evaluates an expression and returns"
                + " a boolean value.\n"
                + "If the value returns true, the statement"
                + " is executed. If the statement is false, it does not.");
        
        while (counter<= 5){
            System.out.println("Counter = " + counter );
            counter = counter + 1;
        }
    }
    
    public static void doWhileLoop(){
        // Do while loop demo goes here
        System.out.print("Do While Loop: ");
        
        // The while loop demo goes here
        Integer counter = 0;
        System.out.print("While Loop:\n");
        System.out.print("The do-while loop works similarly to the while loop,\n"
                + " but the expression is evaluated at the bottom of the loop\n"
                + " rather than at the top.");
        
        do {
            System.out.println("Counter = " + counter );
            counter = counter + 1;
        } while (counter<= 5);
    }
    
    public static void forLoop(){
        // For loop demo goes here
        Integer numberOfLoops =0;
        Integer counter;
        
        System.out.print("For Loop: \n");
        
        System.out.print("The for loop is used to iterate through a range of \n"
                + "values.");
        
        // Get input from user and validate.
        while (numberOfLoops <= 0){
            // Get user input for number of loops.
            System.out.println("Enter a number of times you want the loop to run: ");
            numberOfLoops = getNumberFromUser();
        }
        
        // For loop using user input as controller
        for (counter=0; counter<numberOfLoops+1; counter++){
            System.out.print("\nCurrent count value: "+ counter);
        }
    }
    
    public static void main(String[] args) {
        // Variables
        Integer menuSelection=0;
        Boolean goAgainBool = true;
        
        while (goAgainBool == true){
            // Call the menu.
            menu();
            // Get the users selection.
            while(menuSelection >3 || menuSelection <1){
                System.out.print("Please enter 1, 2, or 3.\n");
                menuSelection = getNumberFromUser();
            }
            // Pass selection to switch.
            switchFunction(menuSelection);
            // Ask if the user wants to go again.
            goAgainBool = goAgain();
        }
        
        
        
    }
    
}
